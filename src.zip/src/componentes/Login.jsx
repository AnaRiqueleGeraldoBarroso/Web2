import React from "react";
import './Login.css';

class Login extends React.Component {
    constructor(props) {
      super(props);
      this.state = {      
        value: '',
        password: ""    
      };
      this.handleChangePassword = this.handleChangePassword.bind(this);
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) {    this.setState({value: event.target.value});  }
    handleChangePassword(event){ this.setState({password: event.target.password}); }
    handleSubmit(event) {
      alert('O usiario foi cadastrado com sucesso: ' + this.state.value);
      event.preventDefault();
    }
  
    render() {
      return (
        <form onSubmit={this.handleSubmit}> <label>
            <h1>Tela de Login do Usuario</h1>
            <p><a href="http://localhost:3000/user/add">User</a></p>
        Email:
        <input type="text" value={this.state.value} onChange={this.handleChange} /> </label> 
        <label>
        Senha:
        <input type="password" value={this.state.password} onChange={this.handleChangePassword} /> 
        </label>

        <input type="submit" value="Enviar" />
        </form>
      );
    }
  }

export default Login;  