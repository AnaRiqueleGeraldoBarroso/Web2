import React from "react";
import axios from 'axios';

class User extends React.Component 
{
    constructor(props) {
      super(props);
      
      this.state = {
        password: '',
        email: "",
        role_id:""    
        };

      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) { 
        event.preventDefault();
        const element = event.target;
        const nome = element.getAttribute("name");
        const value = event.target.value;

        this.setState({[nome]: value})  
    };
    
    
    handleSubmit(event) {
        debugger
        event.preventDefault();
        axios.post('http://localhost:5000/user/add', this.state)
        .then(function (response) {
          console.log(response);
        })
        .catch(function (error) {
            console.log(error);
          });
        }
  
    render() {
      return (
        <form onSubmit={this.handleSubmit}> 
            <label>
                <h1>Tela de Cadastro do Usuario</h1></label>
            <p><a href="http://localhost:3000/login">Login</a></p>
            {"Email:"}
            <input type="text" value={this.state.email} onChange={this.handleChange} name="email"/> 
            <label></label>
            {"Senha:"}
            <input type="password" value={this.state.password} onChange={this.handleChange} name="password"/> 
            <input type="submit" value="Enviar" />
        </form>
      )
    };
}

  
export default User;  