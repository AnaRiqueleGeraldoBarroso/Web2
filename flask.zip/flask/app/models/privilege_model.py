from app import db

class Privilege(db.Model):
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'), primary_key=True, nullable=False)
    resource_id = db.Column(db.Integer, db.ForeignKey('resource.id'),primary_key=True, nullable=False)
    allow_boolean = db.Column(db.Boolean, nullable=False) 
    
    
    def __repr__(self):
        return '<Privilege %r>' % self.allow_boolean
    
    def to_dict(self):
        return {
            "role": self.role_id,
            "resource_id": self.resource_id,
            "allow_boolean": self.allow_boolean

        }