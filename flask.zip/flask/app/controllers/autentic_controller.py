from crypt import methods
from lib2to3.pgen2 import token
from locale import currency
from flask import Flask, jsonify, request
from app import app, db
from app import User
from flask_jwt_extended import create_access_token, create_refresh_token
from flask_jwt_extended import get_jwt_identity
from flask_jwt_extended import jwt_required
from flask_jwt_extended import JWTManager
from werkzeug.security import generate_password_hash, check_password_hash
import json
import jwt
import datetime

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    
    if "email" not in data or data["email"] is None:
        return jsonify ({"error": True, "message": "O email nao foi informado"}), 400
    if "password" not in data or data["password"] is None:
        return jsonify ({"error": True, "message": "A password nao foi informado"}), 400
    
    user = User.query.filter_by(email=data["email"]).first()
    
    if not user:
        return jsonify("Email nao encontrado"), 401
    
    senha = generate_password_hash(data["password"])
    
    if check_password_hash(senha, user.password):
        access_token = create_access_token(identity=user.email)
        refresh_token = create_refresh_token(identity=user.email)
    return jsonify({"access_token":access_token, "refresh_token":refresh_token, "messsage":"Token de acesso foi gerado"})

    
    #return jsonify ({"error": True, "message": "A password  ou user nao foi informado"}), 401

@app.route("/me", methods=["GET"])
@jwt_required()
def me():
    current_identity = get_jwt_identity()
    return jsonify ({"message": current_identity, "message":"logado com sucesso!!"}), 200


@app.route("/protected", methods=["GET"])
@jwt_required(optional=True)
def protected():
    current_identity = get_jwt_identity()
    if current_identity:
        return jsonify(logged_in_as=current_identity)
    else:
        return jsonify(logged_in_as="usuário anonimo")  