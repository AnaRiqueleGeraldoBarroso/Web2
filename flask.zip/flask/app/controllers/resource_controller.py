from app import app, db
from app import Resource
from flask import request, jsonify


@app.route("/resource/add", methods=["POST"])
def resource_add():
    data = request.get_json()

    if "action_id" not in data or data["action_id"] is None:
        return jsonify ({"error": True, "message": "O action_id nao foi informado"}), 400
    if "controller_id" not in data or data["controller_id"] is None:
        return jsonify ({"error": True, "message": "A controller_id nao foi informado"}), 400
    
    resource = Resource()
    resource.action_id = data["action_id"]
    resource.controller_id = data["controller_id"]
    
    
    try:
        db.session.add(resource)
        db.session.commit()
        return jsonify({"error": False})
    except:
        db.session.rollback()
        return jsonify({"error": True, "mensage": "Ja existe"}), 400

@app.route("/resource/list", methods=["GET"])
def resource_list():
    resources = Resource.query.all()
    arr = []
    
    for resource in resources: 
        
        arr.append(resource.to_dict())
        
    return jsonify({"elements": arr, "error": False})

@app.route("/resource/delete/<int:id>", methods = ["DELETE"])
def resource_delete(id):
    resource = Resource.query.get(id)
    
    if resource == None:
        return jsonify(({"message" : "O usuario nao existe", "error": True})), 404
    db.session.delete(resource)

    try:
        db.session.commit()
        return jsonify({"error": False, "message": "Usuario deletado"}), 200
    
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Error ao ser deletado"}), 200    

@app.route("/resource/edit/<int:id>", methods = ["PUT"])
def resource_edit(id):
    resource = Resource.query.get(id)
    
    if resource is None:
        return jsonify(({"message": "O ususario nao editado", "error": True})), 404
    
    data = request.get_json()
    resource.action_id = data["action_id"]
    resource.controller_id = data["controller_id"]
    

    try:
        db.session.commit()
        return jsonify({"error": False, "message": "Usuario editado"}), 200
    
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Error ao ser editado"}), 200

@app.route("/resource/view/<int:id>", methods = ["GET"])
def resource_view(id):
    resource = Resource.query.get(id)
    
    if resource == None:
        return jsonify(({"message" : " nao existe", "error": True})), 404
    return jsonify({
        "data": resource.to_dict(),
        "error": False
    })  