from app import app, db
from app import Action
from flask import request, jsonify


@app.route("/action/add", methods=["POST"])
def action_add():
    data = request.get_json()

    if "name" not in data or data["name"] is None:
        return jsonify ({"error": True, "message": "O name nao foi informado"}), 400
    
    action = Action()
    action.name = data["name"]
    
    try:
        db.session.add(action)
        db.session.commit()
        return jsonify({"error": False})
    except:
        db.session.rollback()
        return jsonify({"error": True, "mensage": "O email ou username ja existe"}), 400

@app.route("/action/list", methods=["GET"])
def action_list():
    actions = Action.query.all()
    arr = []
    
    for action in actions: 
        arr.append(action.to_dict())
        
    return jsonify({"elements": arr, "error": False})

@app.route("/action/delete/<int:id>", methods = ["DELETE"])
def action_delete(id):
    action = Action.query.get(id)
    
    if action == None:
        return jsonify(({"message" : "O usuario nao existe", "error": True})), 404
    db.session.delete(action)

    try:
        db.session.commit()
        return jsonify({"error": False, "message": "Usuario deletado"}), 200
    
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Error ao ser deletado"}), 200    

@app.route("/action/edit/<int:id>", methods = ["PUT"])
def action_edit(id):
    action = Action.query.get(id)
    
    if action is None:
        return jsonify(({"message": "O ususario nao editado", "error": True})), 404
    
    data = request.get_json()
    action.name = data["name"]

    try:
        db.session.commit()
        return jsonify({"error": False, "message": "Action editado"}), 200
    
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Error ao ser editado"}), 200

@app.route("/action/view/<int:id>", methods = ["GET"])
def action_view(id):
    action = Action.query.get(id)
    
    if action == None:
        return jsonify(({"message" : " nao existe", "error": True})), 404
    return jsonify({
        "data": action.to_dict(),
        "error": False
    })  