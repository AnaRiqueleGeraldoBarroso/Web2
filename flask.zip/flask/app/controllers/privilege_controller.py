from app import app, db
from app import Privilege
from flask import request, jsonify

@app.route("/privilege/add", methods=["POST"])
def privilege_add():
    data = request.get_json()

    if "role_id" not in data or data["role_id"] is None:
        return jsonify ({"error": True, "message": "O role_id nao foi informado"}), 400
    if "resource_id" not in data or data["resource_id"] is None:
        return jsonify ({"error": True, "message": "A resource_id nao foi informado"}), 400
    if "allow_boolean" not in data or data["allow_boolean"] is None:
        return jsonify ({"error": True, "message": "A allow nao foi informado"}), 400
    
    privilege = Privilege(role_id = data["role_id"], resource_id = data["resource_id"], allow_boolean = data["allow_boolean"])
    
    try:
        db.session.add(privilege)
        db.session.commit()
        return jsonify({"error": False})
    except:
        db.session.rollback()
        return jsonify({"error": True, "mensage": "ja existe"}), 400


@app.route("/privilege/list", methods=["GET"])
def privilege_list():
    privileges = Privilege.query.all()
    arr = []
    
    for privilege in privileges: 
        
        arr.append(privilege.to_dict())
        
    return jsonify({"elements": arr, "error": False})


@app.route("/privilege/delete/<int:resource_id>&<int:role_id>", methods = ["DELETE"])
def privilege_delete(resource_id, role_id):
    privilege = Privilege.query.filter(resource_id==resource_id,role_id==role_id).first()
    
    if privilege == None:
        return jsonify(({"message" : "O usuario nao existe", "error": True})), 404
    db.session.delete(privilege)

    try:
        db.session.commit()
        return jsonify({"error": False, "message": "Usuario deletado"}), 200
    
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Error ao ser deletado"}), 200    

@app.route("/privilege/edit/<int:resource_id>&<int:role_id>", methods = ["PUT"])
def privilege_edit(resource_id, role_id):
    privilege = Privilege.query.filter(resource_id==resource_id,role_id==role_id).first()
    data = request.get_json()

    try:
        privilege.role_id = data["role_id"]
        privilege.resource_id = data["resource_id"]
        privilege.allow_boolean = data["allow_boolean"]
        db.session.commit()
        return jsonify({"error": False, "message": "Usuario editado"}), 200
    
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Error ao ser editado"}), 200

@app.route("/privilege/view/<int:resource_id>&<int:role_id>", methods = ["GET"])
def privilege_view(resource_id, role_id):
    privilege = Privilege.query.filter(resource_id==resource_id,role_id==role_id).first()
    
    if privilege == None:
        return jsonify(({"message" : " nao existe", "error": True})), 404
    return jsonify({
        "data": privilege.to_dict(),
        "error": False
    })  