from app import app, db
from app import User
from flask import request, jsonify
from werkzeug.security import generate_password_hash


@app.route("/user/add", methods=["POST"])
def user_add():
    data = request.get_json()

    if "email" not in data or data["email"] is None:
        return jsonify ({"error": True, "message": "O email nao foi informado"}), 400
    if "password" not in data or data["password"] is None:
        return jsonify ({"error": True, "message": "A password nao foi informado"}), 400
    
    user = User()
    user.email = data["email"]
    user.password = generate_password_hash(data["password"], method='sha256')
    user.role_id = data["role_id"]
    
    try:
        db.session.add(user)
        db.session.commit()
        return jsonify({"error": False})
    except:
        db.session.rollback()
        return jsonify({"error": True, "mensage": "O email ou username ja existe"}), 400

@app.route("/user/list", methods=["GET"])
def user_list():
    users = User.query.all()
    arr = []
    
    for user in users: 
        
        arr.append(user.to_dict())
        
    return jsonify({"elements": arr, "error": False})

@app.route("/user/delete/<int:id>", methods = ["DELETE"])
def user_delete(id):
    user = User.query.get(id)
    
    if user == None:
        return jsonify(({"message" : "O usuario nao existe", "error": True})), 404
    db.session.delete(user)

    try:
        db.session.commit()
        return jsonify({"error": False, "message": "Usuario deletado"}), 200
    
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Error ao ser deletado"}), 200    

@app.route("/user/edit/<int:id>", methods = ["PUT"])
def user_edit(id):
    user = User.query.get(id)
    
    if user is None:
        return jsonify(({"message": "O ususario nao editado", "error": True})), 404
    
    data = request.get_json()
    user.email = data["email"]
    user.password = data["password"]
    user.role_id = data["role_id"]

    try:
        db.session.commit()
        return jsonify({"error": False, "message": "Usuario editado"}), 200
    
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Error ao ser editado"}), 200

@app.route("/user/view/<int:id>", methods = ["GET"])
def user_view(id):
    user = User.query.get(id)
    
    if user == None:
        return jsonify(({"message" : " nao existe", "error": True})), 404
    return jsonify({
        "data": user.to_dict(),
        "error": False
    })  